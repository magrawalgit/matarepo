package com.ews;

import org.apache.spark.sql.*;
import org.apache.spark.sql.expressions.UserDefinedFunction;
import org.apache.spark.sql.types.DataTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class BatchApp {
    private static final Logger logger = LoggerFactory.getLogger(BatchApp.class);

    public static final String FS_S3_AWS_ACCESS_KEY_KEY = "fs.s3a.awsAccessKeyId";
    public static final String FS_S3_AWS_ACCESS_SECRET_KEY = "fs.s3a.awsSecretAccessKey";

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            logger.error("BATCH_APP - Not Enough arguments. Property file path required.");
            System.exit(1);
        }

        String propertiesFile = args[0];
        AppConfig appConfig = new AppConfig(propertiesFile, BatchAppKeys.values());

        String inputPath = appConfig.getProperty(BatchAppKeys.INPUT_DIR);
        String outputPath = appConfig.getProperty(BatchAppKeys.OUTPUT_DIR);

        logger.info("BATCH_APP - Processing data for: {}", inputPath);
        logger.info("BATCH_APP - Generating output to: {}", outputPath);

        String sparkLaunchMode = appConfig.getProperty(BatchAppKeys.SPARK_LAUNCH_MODE);
        SparkSession spark;

        if (sparkLaunchMode.equalsIgnoreCase("cluster")) {
            spark = SparkSession
                    .builder()
                    .master(appConfig.getProperty(BatchAppKeys.SPARK_MASTER))
                    .appName("BatchSummary").getOrCreate();
        } else {
            spark = SparkSession
                    .builder()
                    .master("local[*]")
                    .appName("BatchSummary").getOrCreate();
        }

        spark.conf().set("spark.sql.session.timeZone", "UTC");
        spark.sparkContext().hadoopConfiguration().set("mapreduce.fileoutputcommitter.algorithm.version", "2");
        spark.sparkContext().setLogLevel(appConfig.getProperty(BatchAppKeys.LOG_LEVEL));

        //spark.sparkContext().hadoopConfiguration().set("fs.s3a.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem");
        //access key and secret keys, required only from local
        spark.sparkContext().hadoopConfiguration().set("fs.s3a.access.key", appConfig.getProperty(BatchAppKeys.AWS_ACCESS_KEY));
        spark.sparkContext().hadoopConfiguration().set("fs.s3a.secret.key", appConfig.getProperty(BatchAppKeys.AWS_SECRET_KEY));


        //UserDefinedFunction strMillisToTs = functions.udf(new StringToTimeStamp(), DataTypes.TimestampType);

        //Read
        Dataset<Row> s3Format = spark
                .read()
                .csv(inputPath);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
        String dt = dateFormat.format(new Date());
        outputPath = outputPath + "/dt=" + dt;

        s3Format
                .repartition(1)
                .write()
                .mode(SaveMode.Overwrite)
                .csv(outputPath);

        logger.info("BATCH_APP - Writing CompanySummaries data to S3 completed successfully!");


    }
}
