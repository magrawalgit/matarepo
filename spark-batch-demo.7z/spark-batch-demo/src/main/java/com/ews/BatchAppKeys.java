package com.ews;

public enum BatchAppKeys implements  Keys {

    LOG_LEVEL("batch_app.loglevel"),
    SPARK_LAUNCH_MODE("batch_app.spark.mode"),
    SPARK_MASTER("spark.master"),
    AWS_ACCESS_KEY("aws.accessKey"),
    AWS_SECRET_KEY("aws.accessSecret"),
    INPUT_DIR("s3.input.dir"),
    OUTPUT_DIR("s3.output.dir")
    ;

    private final String name;

    BatchAppKeys(String s) {
        name = s;
    }

    @Override
    public String getPropertyName() {
        return name;
    }

}
