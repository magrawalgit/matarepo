package com.ews;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.security.InvalidParameterException;
import java.text.MessageFormat;
import java.util.Properties;

public class AppConfig implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(AppConfig.class);
    private final Properties prop = new Properties();

    public AppConfig(String filePath, Keys[] keys) throws IOException {

        try (InputStream input = new FileInputStream(filePath)) {
            prop.load(input);
            logger.info("BATCH_APP - Loading Application Properties");
            for (Keys key : keys) {
                if (prop.getProperty(key.getPropertyName()) == null) {
                    throw new InvalidParameterException(
                            MessageFormat.format("Missing value for key {0}!", key.getPropertyName()));
                }
                logger.info("BATCH_APP - {} --> {}", key.getPropertyName(), prop.getProperty(key.getPropertyName()));
            }
        }
    }

    public String getProperty(Keys key) {
        return prop.getProperty(key.getPropertyName().trim());
    }
}

