package com.ews;

public interface Keys {
    String getPropertyName();
}
