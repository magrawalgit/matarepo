package com.ews;

import org.apache.spark.sql.api.java.UDF1;

import java.sql.Timestamp;

public class StringToTimeStamp implements UDF1<String, Timestamp> {

    public Timestamp call(String s){
        long seconds = Long.parseLong(s);
        return new Timestamp(seconds);
    }
}
